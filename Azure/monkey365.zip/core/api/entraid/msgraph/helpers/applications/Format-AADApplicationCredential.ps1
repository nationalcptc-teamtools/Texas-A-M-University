# Monkey365 - the PowerShell Cloud Security Tool for Azure and Microsoft 365 (copyright 2022) by Juan Garrido
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

Function Format-AADApplicationCredential {
<#
        .SYNOPSIS
		Plugin to format application's credential

        .DESCRIPTION
		Plugin to format application's credential

        .INPUTS

        .OUTPUTS

        .EXAMPLE

        .NOTES
	        Author		: Juan Garrido
            Twitter		: @tr1ana
            File Name	: Format-AADApplicationCredential
            Version     : 1.0

        .LINK
            https://github.com/silverhack/monkey365
    #>
	[CmdletBinding()]
	Param (
        [Parameter(Mandatory=$True, ValueFromPipeline = $True)]
        [Object]$Application
    )
    Process{
        if (@($Application.keyCredentials).Count -gt 0) {
            foreach($credential in $Application.keyCredentials){
                if($null -ne $credential.PsObject.Properties.Item('endDateTime')){
                    $endDate = Get-Date $credential.endDateTime
                    $startDate = Get-Date
                    $timeSpan = New-TimeSpan -Start $startDate -End $endDate
                    $credential | Add-Member -Type NoteProperty -Name expireInDays -Value $timeSpan.Days -Force
                    if($timeSpan.Days -le 0){
                        $credential | Add-Member -Type NoteProperty -Name keyExpired -Value $true -Force
                    }
                    else{
                        $credential | Add-Member -Type NoteProperty -Name keyExpired -Value $false -Force
                    }
                }
            }
		}
        if (@($Application.passwordCredentials).Count -gt 0) {
		    foreach($credential in $Application.passwordCredentials){
                if($null -ne $credential.PsObject.Properties.Item('endDateTime')){
                    $endDate = Get-Date $credential.endDateTime
                    $startDate = Get-Date
                    $timeSpan = New-TimeSpan -Start $startDate -End $endDate
                    $credential | Add-Member -Type NoteProperty -Name expireInDays -Value $timeSpan.Days -Force
                    If($timeSpan.Days -le 0){
                        $credential | Add-Member -Type NoteProperty -Name keyExpired -Value $true -Force
                    }
                    else{
                        $credential | Add-Member -Type NoteProperty -Name keyExpired -Value $false -Force
                    }
                }
            }
		}
        #return application
        $Application
    }
}
